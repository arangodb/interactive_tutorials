Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/9e699545d21e0c58d7ac3eb1db5f112b17383b4d>
